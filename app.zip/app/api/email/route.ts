export const runtime = 'nodejs';

import { NextResponse } from 'next/server';
import nodemailer from 'nodemailer';

type EmailPayload = {
  to: string[];
  subject: string;
  html?: string;
  text?: string;
};

function isEmail(s: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
}

export async function POST(req: Request) {
  try {
    // 1) Parse and validate body
    const { to, subject, html, text } = (await req.json()) as EmailPayload;

    if (!Array.isArray(to) || to.length === 0 || !subject?.trim()) {
      return NextResponse.json(
        { error: 'Missing to/subject' },
        { status: 400 }
      );
    }

    const invalid = to.filter(e => !isEmail(e));
    if (invalid.length) {
      return NextResponse.json(
        { error: `Invalid recipient(s): ${invalid.join(', ')}` },
        { status: 400 }
      );
    }

    // 2) Read env vars
    const { GMAIL_USER, GMAIL_APP_PASSWORD, GMAIL_FROM } = process.env;
    if (!GMAIL_USER || !GMAIL_APP_PASSWORD) {
      return NextResponse.json(
        { error: 'Gmail env vars missing' },
        { status: 500 }
      );
    }
    if (GMAIL_APP_PASSWORD.length !== 16) {
      return NextResponse.json(
        { error: 'App password must be 16 characters (no spaces)' },
        { status: 500 }
      );
    }

    // 3) Configure transporter (force SSL 465; switch to 587 STARTTLS if needed)
  const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  auth: { user: GMAIL_USER!, pass: GMAIL_APP_PASSWORD! },
  tls: { rejectUnauthorized: true },
});



    // Optional in dev: verify handshake
    // await transporter.verify();

    // 4) Prepare message
    const mailFrom = (GMAIL_FROM || GMAIL_USER).trim();
    // Gmail requires the From to be the same mailbox or a verified alias
    if (!isEmail(mailFrom)) {
      return NextResponse.json(
        { error: 'GMAIL_FROM must be a valid email address' },
        { status: 500 }
      );
    }

    const info = await transporter.sendMail({
      from: mailFrom,
      to: to.join(','),
      subject: subject.trim(),
      // Prefer text for deliverability; include html when available
      text: text?.toString() || undefined,
      html: html?.toString() || undefined,
    });

    return NextResponse.json({ messageId: info.messageId });
  } catch (e: any) {
    // Surface a helpful, sanitized error back to the client
    const msg =
      e?.response?.toString?.() ||
      e?.message ||
      'Email failed';
    console.error('Email error:', e); // keep full detail on server logs
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
